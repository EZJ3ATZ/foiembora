// Content script rodando em foiembora.up.railway.app
// Mesmo domínio = sem CORS. Pega o token e salva no storage da extensão.
(async () => {
  try {
    const res = await fetch('/api/me', { credentials: 'include' });
    if (!res.ok) return;
    const data = await res.json();
    if (data.ok && data.token) {
      chrome.storage.local.set({ access_token: data.token });
    }
  } catch (_) {}
})();
