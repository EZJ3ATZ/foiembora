function getCookie(name) {
  const cookies = document.cookie.split(';');
  for (const c of cookies) {
    const [n, v] = c.trim().split('=');
    if (n === name) return decodeURIComponent(v || '');
  }
  return null;
}

function getHeaders() {
  return {
    'x-ig-app-id': '936619743392459',
    'x-csrftoken': getCookie('csrftoken') || '',
    'x-asbd-id': '129477',
    'accept': '*/*',
    'x-requested-with': 'XMLHttpRequest'
  };
}

async function getCurrentUser() {
  const dsUserId = getCookie('ds_user_id');
  if (dsUserId) {
    let username = null;
    try {
      const resp = await fetch(`/api/v1/users/${dsUserId}/info/`, {
        headers: getHeaders(), credentials: 'include'
      });
      if (resp.ok) {
        const data = await resp.json();
        username = data.user?.username;
      }
    } catch (_) {}
    return { id: dsUserId, username };
  }

  const resp = await fetch('/api/v1/accounts/current_user/?edit=true', {
    headers: getHeaders(),
    credentials: 'include'
  });
  if (!resp.ok) throw new Error('Voce precisa estar logado no Instagram nesta aba.');
  const data = await resp.json();
  return { id: data.user?.pk, username: data.user?.username };
}

async function paginate(url) {
  const list = [];
  let nextMaxId = null;
  do {
    const fullUrl = `${url}?count=200${nextMaxId ? '&max_id=' + nextMaxId : ''}`;
    const resp = await fetch(fullUrl, { headers: getHeaders(), credentials: 'include' });
    if (!resp.ok) throw new Error('Instagram bloqueou a requisicao. Tente novamente em alguns minutos.');
    const data = await resp.json();
    list.push(...(data.users || []));
    nextMaxId = data.next_max_id || null;
    if (nextMaxId) await new Promise(r => setTimeout(r, 600));
  } while (nextMaxId);
  return list;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'analyze') return;

  (async () => {
    try {
      chrome.runtime.sendMessage({ action: 'status', text: 'Identificando sua conta...' });
      const user = await getCurrentUser();

      chrome.runtime.sendMessage({ action: 'status', text: 'Carregando quem voce segue...' });
      const following = await paginate(`/api/v1/friendships/${user.id}/following/`);

      chrome.runtime.sendMessage({
        action: 'status',
        text: `Carregando seus seguidores... (voce segue ${following.length})`
      });
      const followers = await paginate(`/api/v1/friendships/${user.id}/followers/`);

      const followerIds = new Set(followers.map(u => u.pk));
      const notFollowingBack = following
        .filter(u => !followerIds.has(u.pk))
        .map(u => ({
          username: u.username,
          full_name: u.full_name,
          profile_pic_url: u.profile_pic_url,
          is_verified: u.is_verified,
          is_private: u.is_private
        }));

      // ---- Sync snapshot com o backend ----
      let unfollowers = [];
      let new_followers = [];
      let snapshotOk = false;

      try {
        const stored = await chrome.storage.local.get('access_token');
        const token = stored.access_token;
        if (token) {
          chrome.runtime.sendMessage({ action: 'status', text: 'Sincronizando com o servidor...' });
          const snapshotResp = await fetch(
            `https://foiembora.up.railway.app/api/snapshot?token=${encodeURIComponent(token)}`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                followers: followers.map(u => u.username),
                following: following.map(u => u.username)
              })
            }
          );
          if (snapshotResp.ok) {
            const snapshotData = await snapshotResp.json();
            unfollowers = snapshotData.unfollowers || [];
            new_followers = snapshotData.new_followers || [];
            snapshotOk = true;
          }
        }
      } catch (_) {
        // Falha silenciosa — ainda retorna dados locais
      }

      chrome.runtime.sendMessage({
        action: 'result',
        notFollowingBack,
        totalFollowing: following.length,
        totalFollowers: followers.length,
        username: user.username,
        unfollowers,
        new_followers,
        snapshotOk
      });
    } catch (err) {
      chrome.runtime.sendMessage({ action: 'error', text: err.message });
    }
  })();

  sendResponse({ ok: true });
  return true;
});
